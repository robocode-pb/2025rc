from godot import exposed, export
from godot import *

#self.get_tree().get_current_scene().find_node("SoundManager").play('jump')

@exposed
class SoundManager(Node2D):

	sounds = [
		{'nаme':'end',   'path':'res://Assets/Sounds/end.wav'},
		{'nаme':'jump',  'path':'res://Assets/Sounds/jump.wav'},
		{'nаme':'shoot', 'path':'res://Assets/Sounds/PIy_piy.wav'}
	]

	players = {} # програвачi звукiв
	
	def _ready(self):
		for sound in self.sounds:
			player = AudioStreamPlayer.new()
			player.stream = ResourceLoader.load(sound['path']) 
			player.volume_db = -15
			self.add_child(player)
			self.players[sound['nаme']] = player
	
	def play(self, nаme):
		self.players[nаme].play()
	
	def jump(self): self.players['jump'].play()
	
	def end(self): self.players['end'].play()
