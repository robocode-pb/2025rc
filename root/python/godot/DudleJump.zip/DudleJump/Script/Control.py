from godot import exposed, export
from godot import *


@exposed
class Control(Control):
	
	buttons = ['Play', 'Exit']
	
	def Play(self):
		self.get_tree().change_scene_to(ResourceLoader.load("res://Scene/Level.tscn"))

	def Exit(self):
		self.get_tree().quit()
	
	def _ready(self):
		for b_name in self.buttons:
			node = self.get_node('Button'+b_name)
			if(node):
				print('Find Button'+b_name)
				node.connect("pressed", self, b_name)

