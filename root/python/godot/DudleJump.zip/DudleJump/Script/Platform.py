from godot import exposed, export
from godot import *


@exposed
class Platform(StaticBody2D):

	def _ready(self):
		self.player = self.get_tree().get_current_scene().find_node("Player", recursive=True)
		
	
	def _process(self, delta): # викликаэться кожний fps
		if self.player.global_position.y+350 < self.global_position.y:
			self.queue_free() 
