
from godot import exposed, export
from godot import *
from Script.high_score import score
import datetime as dt

@exposed
class Player(KinematicBody2D):

	speed = export(int, default=100)
	jump_force = export(int, default=500)
	gravity = export(float, default=1200.0)
	velocity = Vector2()
	position_y_max = export(int, default=0)
	
	def _ready(self): # на початку гри
		self.sprite = self.get_node("Sprite")
		self.text   = self.get_node("RichTextLabel")
		if not self.text :
			print('ПОМИЛКА текст не знайдено')
		self.soundManager = self.get_tree().get_current_scene().find_node("SoundManager")
		self.jetPack = self.get_node('jetPack')
		self.jetPack.hide()
		self.jetPack_timer = None
	
	def _input(self, event):
		if isinstance(event, InputEventKey):
			if event.pressed and not event.echo:
				key_name = str(OS.get_scancode_string(event.scancode)).upper().strip()
				if key_name in ('A', 'LEFT'):
					self.velocity.x = -self.speed
					self.sprite.flip_h = False
					self.jetPack.position = Vector2(abs(self.jetPack.position.x), self.jetPack.position.y)
				elif key_name in ('D', 'RIGHT'):
					self.velocity.x = self.speed
					self.sprite.flip_h = True
					self.jetPack.position = Vector2(-abs(self.jetPack.position.x), self.jetPack.position.y)
			else:
				self.velocity.x = 0

	def _physics_process(self, delta):
		# Гравітація
		self.velocity.y += self.gravity * delta
		
		if Input.is_action_pressed("ui_select") and not self.jetPack.visible:	
			self.velocity.y = -500
			self.soundManager.end()
		
		
		
		if self.jetPack.visible:
			self.velocity.y = 0
			self.position = Vector2(self.position.x, self.position.y-10)
			if self.jetPack_timer < dt.datetime.now(): self.jetPack.hide()

		# Рух
		self.velocity = self.move_and_slide(self.velocity, Vector2.UP)
 
		# Якщо гравець торкається платформи знизу — стрибок (імітація doodle jump)
		if self.is_on_floor():
			self.soundManager.jump()
			self.velocity.y = -self.jump_force
		
		position_y = int(self.position.y)*-1
		
		# виводимо тiльки максимальну висоту 
		if self.position_y_max < position_y:
			self.position_y_max = position_y
			self.text.text = f'Height {self.position_y_max}'
			score(self.position_y_max)
		
		collision = self.move_and_collide(self.velocity * delta)
		if collision and not self.jetPack.visible:
			groups = collision.collider.get_groups()
			if 'Enemy' in groups:
				print("Зіткнення з ворогом!")
				self.get_tree().change_scene_to(ResourceLoader.load("res://Scene/End.tscn"))
			if 'jetpack' in groups:
				print("Зіткнення з jetpack!")
				self.jetPack.show()
				collision.collider.queue_free()
				self.jetPack_timer =  dt.datetime.now()+dt.timedelta(0,5)
				if self.sprite.flip_h:
					self.jetPack.position = Vector2(-abs(self.jetPack.position.x), self.jetPack.position.y)
				
		
		if self.position_y_max > position_y+300:
			self.soundManager.end()
			self.soundManager.end()
		
		if self.position_y_max > position_y+6000:
			self.get_tree().change_scene_to(ResourceLoader.load("res://Scene/End.tscn"))
