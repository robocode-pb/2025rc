 destroy_enemys = 0

def load_enemys():
	global destroy_enemys
	try:
		with open('destroy_enemys', 'r') as f:
			destroy_enemys = int(f.read())  # читаємо та перетворюємо на int
	except:
		print('Error loading destroy_enemys')
		destroy_enemys = 0  # якщо не вдалося прочитати, встановлюємо 0

def save_enemys():  
	with open('destroy_enemys', 'w') as f:
		f.write(str(destroy_enemys))  # записуємо у файл, перетворюючи на рядок


def enemys(new_score=None):
	global destroy_enemys
	if new_score is None:
		return destroy_enemys # повертаємо поточний рекорд
	elif new_score > destroy_enemys:
		destroy_enemys = new_score
		save_high_score()  # зберігаємо новий рекорд
