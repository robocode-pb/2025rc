# high_score.py

high_score = 0

def load_high_score():
	global high_score
	try:
		with open('high_score', 'r') as f:
			high_score = int(f.read())  # читаємо та перетворюємо на int
	except:
		print('Error loading high score')
		high_score = 0  # якщо не вдалося прочитати, встановлюємо 0

def save_high_score():
	with open('high_score', 'w') as f:
		f.write(str(high_score))  # записуємо у файл, перетворюючи на рядок

load_high_score() 

def score(new_score=None):
	global high_score
	if new_score is None:
		return high_score # повертаємо поточний рекорд
	elif new_score > high_score:
		high_score = new_score
		save_high_score()  # зберігаємо новий рекорд
