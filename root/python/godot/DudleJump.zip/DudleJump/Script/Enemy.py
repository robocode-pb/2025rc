from godot import exposed, export
from godot import KinematicBody2D, Vector2

@exposed
class Enemy(KinematicBody2D):
	speed = export(float,100.0) 
	left_limit = export(float,-200.0)
	right_limit = export(float,200.0)

	direction = 1
	start_position = Vector2()

	def _ready(self):
		self.start_position = self.position
		#self.add_to_group("Enemy")

	def _process(self, delta):
		self.position += Vector2(self.direction * self.speed * delta, 0)


		if self.position.x > self.start_position.x + self.right_limit:
			self.direction = -1
		elif self.position.x < self.start_position.x + self.left_limit:
			self.direction = 1


