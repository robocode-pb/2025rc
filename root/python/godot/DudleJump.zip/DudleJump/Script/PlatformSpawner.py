from godot import exposed, Node2D, ResourceLoader, Vector2

from random import randint

@exposed
class PlatformSpawner(Node2D):
	def _ready(self):
		self.platform_scene = ResourceLoader.load("res://Scene/Platform.tscn")
		# створюэмо змынну для збереження обэкту ворога
		self.enemy = ResourceLoader.load("res://Scene/Enemy.tscn")
		self.jetpack = ResourceLoader.load("res://Scene/jetpack.tscn")
		print(self.jetpack)
		self.enemy_random_bohdan = 90
		self.player = self.get_tree().get_current_scene().find_node("Player", recursive=True)
		self.spawn_interval_y = (50, 120)  # Мінімальна та максимальна відстань між платформами по Y
		self.spawn_above_distance = 1000    # Наскільки далеко вгору наперед спавнити платформи
		self.max_platforms_per_frame = 20   # Обмеження для уникнення фризів
		
		self.last_spawn_y = self.player.global_position.y
		self.spawn_limit_y = self.last_spawn_y - self.spawn_above_distance

	def _process(self, delta):
		self.spawn_above_distance += self.player.global_position.y % 100
		self.spawn_limit_y = self.player.global_position.y - self.spawn_above_distance
		screen_width = int(self.get_viewport().get_visible_rect().size.x/4)

		spawned = 0
		while self.last_spawn_y > self.spawn_limit_y and spawned < self.max_platforms_per_frame:
			self.last_spawn_y -= randint(*self.spawn_interval_y)
			random_x = randint(-screen_width, screen_width)
			
			platform = self.platform_scene.instance()
			platform.global_position = Vector2(random_x, self.last_spawn_y)
			self.get_tree().get_current_scene().add_child(platform)
			
			if randint(1,5) == 1:
				jetpack = self.jetpack.instance()
				jetpack.global_position = Vector2(random_x, self.last_spawn_y-20)
				self.get_tree().get_current_scene().add_child(jetpack)
			
			if randint(0, 100) > self.enemy_random_bohdan:
				enemy = self.enemy.instance()
				enemy.global_position = Vector2(random_x, self.last_spawn_y)
				self.get_tree().get_current_scene().add_child(enemy)
			
			spawned += 1
