from godot import exposed, export
from godot import KinematicBody2D, Vector2

@exposed
class Bullet(KinematicBody2D):

	speed = export(float, 400.0)  # Швидкість кулі
	direction = export(int, 0)    # -1 = вліво, 0 = прямо, 1 = вправо

	def _physics_process(self, delta):
		velocity = Vector2(self.direction * self.speed, -self.speed)
		
		collision = self.move_and_collide(velocity * delta)
		if collision:
			collider = collision.collider
			#if collider.is_in_group("Player"):
			#	print('Player')
				
			if collider.is_in_group("Enemy"):
				text = self.get_tree().get_current_scene().find_node("TextEnemys")
				text.text = str(text.text.to_int()+1)
				save_enemys(text.text.to_int())
				# text.text -> 'godot.buЫiltins.GDString'
				print("Пуля влучила у ворога!")
				collider.queue_free()  # Видаляємо ворога
				self.queue_free()      # Видаляємо кулюс



def save_enemys(enemys):
	try:
		with open('destroy_enemys', 'r') as f:
			destroy_enemys = int(f.read())  # читаємо та перетворюємо на int
	except:
		destroy_enemys = 0
	if(destroy_enemys < enemys):
		with open('destroy_enemys', 'w') as f:
			f.write(str(enemys))  # записуємо у файл, перетворюючи на рядок 
