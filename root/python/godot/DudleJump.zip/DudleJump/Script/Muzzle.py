from godot import exposed, export, ResourceLoader
from godot import *
from godot  import OS

@exposed
class Muzzle(Node2D):
	bullet = ResourceLoader.load("res://Scene/Bullet.tscn")


	def _input(self, event):
		if isinstance(event, InputEventKey):
			if event.pressed and not event.echo:
				key_name = str(OS.get_scancode_string(event.scancode)).upper().strip()
				
				def _create_bullet(direction):
					bullet = self.bullet.instance()
					bullet.position = self.position
					bullet.direction = direction
					self.get_parent().add_child(bullet)
				
				if(key_name == 'W'): _create_bullet(0)
				if(key_name == 'Q'): _create_bullet(-1)
				if(key_name == 'E'): _create_bullet(1)


			
		
		#if(Input.is_mouse_button_pressed(0)):
		#	print('mose down')
		#	bullet = self.bullet.instance()
		#	bullet.global_position = Vector2(self.global_position.x, self.global_position.y)
		#	self.get_tree().get_current_scene().add_child(bullet)
			
