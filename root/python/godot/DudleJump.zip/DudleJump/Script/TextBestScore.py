from godot import exposed, export
from godot import *
from Script.high_score import score

@exposed
class TextBestScore(RichTextLabel):
	def _ready(self):
		self.text = f"Best Score: {score()}"
