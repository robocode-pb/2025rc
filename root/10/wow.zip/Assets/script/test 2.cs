using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour 
{
    // Start is called before the first frame update
    void Start()
    {
       Debug.Log("Hello playkitten! I'm Unity! I'm here to mess with you!.. Anyway I'll stop speaking to a Human and get cleaning suply it will be messy...");
    }

    // Update is called once per frame
    void Update()
    {
      
    }
}
