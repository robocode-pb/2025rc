using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jewel : MonoBehaviour
{
 [SerializeField] int Score = 0;
 [SerializeField] GameObject ScoreText;
 [SerializeField] GameObject Canvas;
 

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D collider){
        if(collider.gameObject.tag == "coin" ){
            Destroy(obj: collider.gameObject);
            Score += 1;

        }

        if(collider.gameObject.tag == "end" ){
            Canvas.active = true;

        }
    }
}

