using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Telporters : MonoBehaviour
{
    [SerializeField] Vector3 tpPosf;
    void Start()
    {
     
    }

    // Update is called once per frame
    void Update()
    {
     
    }

   void  OnCollisionEnter2D(Collision2D col){
      if ( col.gameObject.CompareTag("Apple")){
        col.gameObject.transform.position = tpPosf;
      }
    }
}
