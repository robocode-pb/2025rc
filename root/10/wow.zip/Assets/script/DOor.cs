using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class DOor : MonoBehaviour
{
    [SerializeField] Vector3 tpPos;
    void Start()
    {
     
    }

    // Update is called once per frame
    void Update()
    {
     
    }

   void  OnCollisionEnter2D(Collision2D col){
      if ( col.gameObject.CompareTag("Apple")){
      //  transform.position = new Vector3(transform.position.x, transform.position.x+0.3f, 0);
      transform.Translate(Vector2.up * 0.1f);
      }
    }
}
