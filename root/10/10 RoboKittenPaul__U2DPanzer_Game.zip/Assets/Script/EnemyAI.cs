using UnityEngine;
using UnityEngine.UI;  // для Slider
using UnityEngine.SceneManagement;
public class EnemyAI : MonoBehaviour
{
    public Transform muzzle;
    public GameObject bulletPrefab;

    public float detectRadius = 10f;
    public float attackRadius = 5f;
    public float moveSpeed = 2f;
    public float rotationSpeed = 120f;
    public float fireCooldown = 1f;

    public Slider hpSlider;       // UI Slider для HP ворога
    public float maxHP = 100f;    // Максимальне здоров'я

    private float currentHP;
    private float fireTimer = 0f;
    private Rigidbody2D rb;
    private Transform player;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        GameObject playerObj = GameObject.Find("Player");
        if (playerObj != null)
            player = playerObj.transform;
        else
            Debug.LogWarning("Player not found in scene!");

        currentHP = maxHP;
        if (hpSlider != null)
        {
            hpSlider.minValue = 0;
            hpSlider.maxValue = maxHP;
            hpSlider.value = currentHP;
        }
    }

    void FixedUpdate()
    {
        if (player == null) return;

        float distance = Vector2.Distance(transform.position, player.position);

        if (distance < detectRadius)
        {
            // Розрахунок напряму
            Vector2 direction = (player.position - transform.position).normalized;
            float targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg - 90f;
            float angle = Mathf.MoveTowardsAngle(transform.eulerAngles.z, targetAngle, rotationSpeed * Time.fixedDeltaTime);
            rb.MoveRotation(angle);

            if (distance > attackRadius)
            {
                // Танковий рух вперед
                Vector2 forward = transform.up * moveSpeed;
                rb.velocity = forward;
            }
            else
            {
                rb.velocity = Vector2.zero;

                if (fireTimer <= 0f)
                {
                    Shoot();
                    fireTimer = fireCooldown;
                }
            }
        }
        else
        {
            rb.velocity = Vector2.zero;
        }

        fireTimer -= Time.fixedDeltaTime;
    }

    void Shoot()
    {
        if (bulletPrefab && muzzle)
        {
            Instantiate(bulletPrefab, muzzle.position, muzzle.rotation);
        }
    }

    public void TakeDamage(float damage)
    {
        currentHP -= damage;
        if (currentHP < 0) currentHP = 0;
        UpdateHpSlider();

        if (currentHP == 0)
            Die();
    }

    private void UpdateHpSlider()
    {
        if (hpSlider != null)
        {
            hpSlider.value = currentHP;
        }
    }

    private void Die()
    {
        // Тут можна додати анімацію смерті, ефекти і т.п.
        Destroy(gameObject);
        Text TextEnemy = GameObject.Find("TextEnemy").GetComponent<Text>();
        int enemy = 0;
        int.TryParse(TextEnemy.text, out enemy);
        TextEnemy.text = "" + (enemy + 1); //збільшуємо кількість знищених ворогів
                                           // int.ToInt(TextEnemy.text) + 1
        if (enemy+1 >= 5) SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectRadius);

        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
    void OnTriggerEnter2D(Collider2D c){
        if (c.gameObject.CompareTag("PlayerBullet"))
        {
            Destroy(c.gameObject);
            TakeDamage(10);
        }
    }
}
