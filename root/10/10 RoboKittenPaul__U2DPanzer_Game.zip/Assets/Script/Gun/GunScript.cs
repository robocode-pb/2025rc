﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunScript : MonoBehaviour
{
    [SerializeField] GameObject muzzle;
    private Transform muzzleTr;
    [SerializeField] private GameObject shellPrefab;
    [SerializeField] private float gunReload;
    private bool canShoot = true;   


    void Start()
    {
        muzzleTr = muzzle.GetComponent<Transform>();
    }
    private void Update()
    {
        if ((Input.GetKeyDown(KeyCode.LeftControl) || Input.GetMouseButtonDown(0)) && canShoot)
        {
            Debug.Log("Shoot");
            canShoot = false;
            Instantiate(shellPrefab, muzzleTr.transform.position, muzzleTr.transform.rotation);
            Invoke("Relod", gunReload);
        }
    }
    private void Relod()
    {
        canShoot = true;
    }
}
