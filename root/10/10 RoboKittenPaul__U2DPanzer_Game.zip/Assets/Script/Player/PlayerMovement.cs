﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float tankFuil;
    private float tankFuilMax;
    [SerializeField] private float tankSpeed = 50f;
    [SerializeField] private float rotateSpeed = 1f;
    private Rigidbody2D rb2d;
    private bool isMovement;

    private Vector3 direction;
    private float rotationValue;
    public HoldButton btF;
    public HoldButton btR;
    public HoldButton btB;
    public HoldButton btL;


    [SerializeField] private Slider fuelSlider;

    private void Start()
    {
        tankFuil = 100;
        tankFuilMax = tankFuil;

        if (fuelSlider != null)
        {
            fuelSlider.minValue = 0;
            fuelSlider.maxValue = tankFuilMax;
            fuelSlider.value = tankFuil;
        }

        InvokeRepeating("EngineWorking", 0.5f, 1f);
        rb2d = GetComponent<Rigidbody2D>();
    }
    private void Update()
    {
        MovementInput();
    }
    public void AddFuil(float value)
    {
        tankFuil += value;
        if (tankFuil > tankFuilMax) tankFuil = tankFuilMax;
        if (tankFuil < 0) tankFuil = 0;

        UpdateFBar();
    }
    private void MovementInput()
    {
        // Forward/Backward movement (W/S or Up/Down arrows)
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow) )
            direction = (transform.up * tankSpeed) * Time.fixedDeltaTime;
        else if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
            direction = (-transform.up * tankSpeed) * Time.fixedDeltaTime;
        else
            direction = Vector3.zero;

        // Rotation (A/D or Left/Right arrows)
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
            rotationValue = rb2d.rotation + rotateSpeed;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
            rotationValue = rb2d.rotation - rotateSpeed;
    }


    private void FixedUpdate()
    {
        rb2d.velocity = direction;
        rb2d.MoveRotation(rotationValue);
    }
    private void EngineWorking()
    {
        if (tankFuil > 0)
        {
            if (rb2d.velocity != Vector2.zero)
            {
                tankFuil -= 2f;
            }
            else
            {
                tankFuil -= 0.5f;
            }
            if (tankFuil < 0) tankFuil = 0;
            UpdateFBar();
        }
        else
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().name
            );
        }
    }
    private void UpdateFBar()
    {
        if (fuelSlider == null) return;

        fuelSlider.value = Mathf.Clamp(tankFuil, 0, tankFuilMax);
    }
}
