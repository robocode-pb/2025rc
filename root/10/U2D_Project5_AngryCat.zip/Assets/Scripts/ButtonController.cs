using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour{
    public void ClickRestart(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void ClickNext(){
        ClickLevel(
            SceneManager.GetActiveScene().buildIndex+1
        );
    }
    public void ClickMenu(){
        SceneManager.LoadScene(0);
    }

    public void OpenSettings(){
       SceneManager.LoadScene("Settings");
    }

    public void ClickLevel(int levelBuildIndex){
        if (levelBuildIndex < 0 || levelBuildIndex >= SceneManager.sceneCountInBuildSettings)
        {
            Debug.LogWarning("Level index out of range: " + levelBuildIndex);
            SceneManager.LoadScene(0);
            return;
        }
        SceneManager.LoadScene(levelBuildIndex);
    }

    public void ClickQuit(){
        Application.Quit();
    }
}