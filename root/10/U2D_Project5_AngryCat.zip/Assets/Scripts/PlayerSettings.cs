

using UnityEngine;
using UnityEngine.UI;

public class PlayerSettings : MonoBehaviour
{
    public int hp;
    public Slider hpSlider;
    void Start()
    {
        hpSlider.maxValue = hp;
        
    }


    void Update()
    {
        hpSlider.value = hp;
        if(hp<=0){
           FindObjectOfType<OKScript>().ShowPanelded(); 
           Destroy(gameObject);
        }
    }
    void OnTriggerEnter2D(Collider2D c){
        if(c.gameObject.CompareTag("Obstacle")){
            hp--;
        }
    }
}
