using UnityEngine;

public class MovingObstacleScript : MonoBehaviour
{
    public Transform start, end;
    public float speed = 10.0f;
    bool up = false;
    void Update(){
        if       (transform.position.y >= end.position.y){
            up = false;
        }else if (transform.position.y <= start.position.y){
            up = true;
        }
        if (up == true){
            transform.Translate(  Vector3.up * speed/4 * Time.deltaTime );
        }else{
            transform.Translate( -Vector3.up *speed* Time.deltaTime );
        }
    }
}
