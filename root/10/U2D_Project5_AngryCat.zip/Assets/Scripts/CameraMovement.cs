using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    // [SerializeField] private Transform target;
    // private Vector3 startPoint;
    // private Camera myCam;

    // private void Awake()
    // {
    //     myCam = Camera.main;
    //     startPoint = transform.position;
    // }

    // private void SetMovement()
    // {
    //     if(target.position.x > transform.position.x && !target.GetComponent<PlayerLaunch>().canDrag)
    //     {
    //         Vector3 newPos = new Vector3(target.position.x, transform.position.y, transform.position.z);
    //         transform.position = Vector3.Lerp(transform.position, newPos, Time.deltaTime * 2);
    //     }
    // }
    // public void MoveToStart()
    // {
    //     transform.position = startPoint;
    // }

    // private void LateUpdate()
    // {
    //     if(target != null)
    //     {
    //         SetMovement();
    //     }
    // }

}
