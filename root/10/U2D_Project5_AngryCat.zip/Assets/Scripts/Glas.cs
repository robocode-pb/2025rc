using UnityEngine;

public class Glas : MonoBehaviour
{
 void OnTriggerEnter2D(Collider2D c)
 {
     if (c.gameObject.CompareTag("Player"))
     {
        Debug.Log("player");
         foreach (Rigidbody2D child in transform.GetComponentsInChildren<Rigidbody2D>())
         {
            Debug.Log("Glas: " + child.name);
             child.bodyType = RigidbodyType2D.Dynamic;
         }
     }
 }
}
