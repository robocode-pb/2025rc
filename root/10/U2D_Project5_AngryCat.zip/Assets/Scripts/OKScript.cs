using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class OKScript : MonoBehaviour
{
    public int StarTime1 = 2;
    public int StarTime2 = 10;
    public int StarTime3 = 20;
    public int StarTime4 = 40000000;
    public Text timerText;
    public Text starText;
    public GameObject Panelokpanel;
    public GameObject Paneldedpanel;
   
    int timer = 0;
    private Coroutine tickCoroutine;
    IEnumerator TickCoroutine()
    {
        while (true)
        {
            yield return new WaitForSeconds(1f);
            timer += 1;
            timerText.text = "Time:" + timer + "s";
            Debug.Log(timer);
        }
    }

    public void ShowPanel()
    {
        StopCoroutine(tickCoroutine);
        Panelokpanel.SetActive(true);
        int stars;
        if (timer <= StarTime1)
        {
            stars = 4;
        }
        else if (timer <= StarTime2)
        {
            stars = 3;
        }
        else if (timer <= StarTime3)
        {
            stars = 2;
        }
        else if (timer <= StarTime4)
        {
            stars = 1;
        }
        else
        {
            stars = 0;
        }
        starText.text = "Stars: " + stars + " stars";
        int levelNumber = UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex;
        PlayerPrefs.SetInt("levelStar" + levelNumber, stars);
        PlayerPrefs.Save();
    }

    public void ShowPanelded()
    {
        StopCoroutine(tickCoroutine);
        Paneldedpanel.SetActive(true);
    }

    public void StartTimer()
    {
        if (tickCoroutine == null)
        {
        Time.timeScale = 1;
        tickCoroutine = StartCoroutine(TickCoroutine());
        }
    }
}
