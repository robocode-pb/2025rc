using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PLayButtonControllerAnimate : MonoBehaviour
{

    public RectTransform PlayPanelAnimate;
    public float leftValue;
    int startLeftPosition;
    bool isPositionStart = true;
    void Start()
    {
        // Знаходимо компонент Button і додаємо обробник натискання
        GetComponent<Button>().onClick.AddListener(Click);
    }

    void Click()
    {
        if (isPositionStart)
        {
            PlayPanelAnimate.anchoredPosition = new Vector2(PlayPanelAnimate.anchoredPosition.x - leftValue, PlayPanelAnimate.anchoredPosition.y);
        }
        else
        {
            PlayPanelAnimate.anchoredPosition = new Vector2(PlayPanelAnimate.anchoredPosition.x + leftValue, PlayPanelAnimate.anchoredPosition.y);
        }
        isPositionStart = !isPositionStart;
    }
}
