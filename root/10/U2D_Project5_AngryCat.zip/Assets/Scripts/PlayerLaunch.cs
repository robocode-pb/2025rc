using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLaunch : MonoBehaviour
{
    [SerializeField] private float forceValue = 200f;
    [SerializeField] private float minSpeedToDrag = 10f;
    [SerializeField] private float maxDragDistance = 3f;
    [SerializeField] private GameObject point;

    private Rigidbody2D rb;
    private Camera mainCamera;
    private Vector2 startPosition;
    public bool canDrag;
    private bool followPlayer;

    public static bool isNonVisible;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        mainCamera = Camera.main;
    }

    private void Start()
    {
        rb.isKinematic = true;
        point.SetActive(false);
        followPlayer = false;
    }

    private void Update()
    {
        if (followPlayer)
        {
            mainCamera.transform.position =
                Vector3.Lerp(
                    mainCamera.transform.position,
                    new Vector3(
                        transform.position.x,
                         transform.position.y,
                        // mainCamera.transform.position.y,
                        -10
                    ),
                    0.1f
                );
        }
    }

    private void OnMouseDown()
    {
        FindObjectOfType<OKScript>().StartTimer();
        float playerSpeed = rb.velocity.magnitude;
        if (playerSpeed < minSpeedToDrag)
        {
            canDrag = true;
            rb.isKinematic = true;
            rb.velocity = Vector2.zero;
            rb.angularVelocity = 0f;
            rb.freezeRotation = true;                 // Зупинка обертання
            transform.rotation = Quaternion.identity; // Встановлення 0 градусів

            startPosition = rb.position;
            point.transform.position = transform.position;
            point.SetActive(true);
            isNonVisible = false;
            followPlayer = false;
        }
    }

    private void OnMouseDrag()
    {
        if (canDrag && !isNonVisible)
        {
            Vector2 mousePosition = mainCamera.ScreenToWorldPoint(Input.mousePosition);
            Vector2 dragVector = mousePosition - startPosition;

            if (dragVector.magnitude > maxDragDistance)
            {
                dragVector = dragVector.normalized * maxDragDistance;
            }

            transform.position = startPosition + dragVector;
        }
        else if (canDrag && isNonVisible)
        {
            transform.position = point.transform.position;
        }
    }

    private void OnMouseUp()
    {
        if (canDrag && !isNonVisible)
        {
            Vector2 currentPos = rb.position;
            Vector2 direction = startPosition - currentPos;
            rb.isKinematic = false;
            rb.freezeRotation = false; // Дозволити обертання після запуску
            rb.AddForce(direction * forceValue);

            canDrag = false;
            point.SetActive(false);
            followPlayer = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Finish"))
        {
            FindObjectOfType<OKScript>().ShowPanel();
            Destroy(gameObject);
        }
    }

    private void OnBecameInvisible()
    {
        isNonVisible = true;
    }
}
