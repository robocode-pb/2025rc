using UnityEngine;
using UnityEngine.UI;

public class AudioManager : MonoBehaviour
{
    [SerializeField] Slider VolumeMusic;
    [SerializeField] Slider VolumeAudio;

    AudioSource audioSource;
    AudioSource musicSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        musicSource = GetComponentInChildren<AudioSource>();
        musicSource.volume =  PlayerPrefs.GetFloat("VolumeMusic", 1f);
        audioSource.volume =  PlayerPrefs.GetFloat("VolumeAudio", 1f);
        if (VolumeMusic != null)
        {
            float musicValue = PlayerPrefs.GetFloat("VolumeMusic", 1f);
            VolumeMusic.value = musicValue;
            VolumeMusic.onValueChanged.AddListener(OnMusicVolumeChanged);
        }

        if (VolumeAudio != null)
        {
            float audioValue = PlayerPrefs.GetFloat("VolumeAudio", 1f);
            VolumeAudio.value = audioValue;
            VolumeAudio.onValueChanged.AddListener(OnAudioVolumeChanged);
        }
    }

    void OnMusicVolumeChanged(float value)
    {
        PlayerPrefs.SetFloat("VolumeMusic", value);
        musicSource.volume =  PlayerPrefs.GetFloat("VolumeMusic", 1f);
    }

    void OnAudioVolumeChanged(float value)
    {
        PlayerPrefs.SetFloat("VolumeAudio", value);
        audioSource.volume =  PlayerPrefs.GetFloat("VolumeAudio", 1f);
    }
    
    [SerializeField] AudioClip rubberPress; // резинка рогатки натягнута
    [SerializeField] AudioClip rubberReleased; // резинка рогатки відпущена
    [SerializeField] AudioClip finish; // кінець рівня

    // FindObjectOfType<AudioManager>()?.PlayRubberPress();

    public void PlayRubberPress() { audioSource.PlayOneShot(rubberPress); }
    public void PlayRubberReleased() { audioSource.PlayOneShot(rubberReleased); }
    public void PlayFinish() { audioSource.PlayOneShot(finish); }


}