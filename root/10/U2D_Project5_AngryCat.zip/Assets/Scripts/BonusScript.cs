using UnityEngine.UI;
using UnityEngine;
public class BonusScript : MonoBehaviour
{
    public bool Btime = false;
    public bool Bgravity = false;
    public bool Bsmall = false;
    public bool Bpaw = false;
    public bool Blight = false;
    public bool Bhealth = false;
    int[] price = {150,300,300,1000,1000, 1473};
    public Button[] buttons = new Button[5];
    void ButtonClick(int index){
        if(PlayerPrefs.GetInt("money") >= price[index]){
            PlayerPrefs.SetInt("money",
            PlayerPrefs.GetInt("money") - price[index]);
            buttons[index].interactable = false;
        }
    }
        
    
}
