using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class PedalController : MonoBehaviour,
                               IPointerDownHandler,
                               IPointerUpHandler    {

    public Sprite pedalDown, pedalUp;

    public bool pedalForward;
    public GameObject car;
    public void OnPointerDown(PointerEventData eventData){
        GetComponent<Image>().sprite = pedalDown;
        if (pedalForward){
            car.GetComponent<CarController>().moveForward = true;
        } else {
            car.GetComponent<CarController>().moveBackward = true;
        }       
    }

    public void OnPointerUp(PointerEventData eventData){
        GetComponent<Image>().sprite = pedalUp;
        if (pedalForward){
            car.GetComponent<CarController>().moveForward = false;
        } else {
            car.GetComponent<CarController>().moveBackward = false;
        }       
    }
    void Start(){ }

    void Update(){}
}
