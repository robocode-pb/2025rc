using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Move : MonoBehaviour
{
    [SerializeField] float Speed;
    [SerializeField] Vector3 position;
    // Start is called before the first frame update
    void Start()
    { 
        Debug.Log(
            "Hello World from Unity :)"
        );
        transform.position = position;
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 move;
        move.x = Input.GetAxisRaw("Horizontal");
        move.y = Input.GetAxisRaw("Vertical");
        transform.Translate(move * Speed * Time.deltaTime);
        // TODO наступного разу

        // if(умова){дія}
        // if (Input.GetKey){ // вверх

        // }

    }
}
