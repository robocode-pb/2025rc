using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class PC : MonoBehaviour
{
    [SerializeField] int Score = 0;
    [SerializeField] GameObject ScoreText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D collider){
        if(collider.gameObject.tag == "Coin"){
            Destroy(collider.gameObject);
            Score += 1;
        }   ScoreText.GameComponent<Text>().text = " " + Score;
    }
}