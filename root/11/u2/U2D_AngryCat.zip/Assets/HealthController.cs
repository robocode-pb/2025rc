
using UnityEngine;

using UnityEngine.UI;

public class HealthController : MonoBehaviour {
public Slider hpSlider;
int hp = 100;

    void Start(){
        hpSlider.maxValue = hp;
        hpSlider.value = hp;
        
    }

    void OnCollisionEnter2D(Collision2D c){
      if(c.gameObject.CompareTag("Peresshkods")){
        hp -= c.gameObject.GetComponent<ObstacleSetting>().damageValue;
         }
    }
}
