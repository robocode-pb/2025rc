using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class PlayerLaunch : MonoBehaviour
{
    [SerializeField] private float forceValue;
    [SerializeField] private float minSpeedToDrag;
    private Rigidbody2D rb;
    private Camera mainCamera;
    private Vector2 startPosition;
    public bool canDrag;

    [SerializeField] private GameObject point;

    public static bool isNonVisible;
    [SerializeField]
    // private ResultController results; //тут помилка, виправте її

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        mainCamera = Camera.main;
    }

    private void Start()
    {
        rb.isKinematic = true;
      //  point.SetActive(false);


        int age = 5;
        string text = "Hello";
        Debug.Log(text + ", " + age.ToString()); //Hello, 5 
        Debug.Log(string.Format("{0}, {1}", text, age));
        Debug.Log($"{text}, {age}");
    }
    private void Update()
    {
        mainCamera.transform.position = 
        Vector3.Lerp(mainCamera.transform.position, new Vector3(transform.position.x, transform.position.y, -10), 0.5f);
        new Vector3(transform.position.x, transform.position.y, -10);
    }

    private void OnMouseDown()
    {
        float playerSpeed = rb.velocity.magnitude;
        if(playerSpeed < minSpeedToDrag )
        {
            canDrag = true;
            rb.isKinematic = true;
            rb.velocity = Vector2.zero;
            point.transform.position = this.transform.position;

            // results.StopWatch(); 
            isNonVisible = false; 
        }
    }
    private void OnMouseUp()
    {
        if (canDrag && !isNonVisible)
        {
            Vector2 currentPos = rb.position;
            Vector2 direction = startPosition - currentPos;
            rb.isKinematic = false;
            rb.AddForce(direction * forceValue);
            canDrag = false;
            point.SetActive(false);
            // results.StartWatch();
        }
    }
    private void OnMouseDrag()
    {
        if (canDrag  && !isNonVisible)
        {
            Vector2 mousePosition = mainCamera.ScreenToWorldPoint(Input.mousePosition);
            transform.position = mousePosition;
        }
        else if(canDrag && isNonVisible)
        {
            transform.position = point.transform.position;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Finish"))
        {
            // results.StopWatch();
            // results.SaveResult();
            Destroy(this.gameObject);
        }   
    }

    private void OnBecameInvisible()
    {
        isNonVisible = true;
    }
}