﻿using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb;
    public float moveH, moveV;
    [SerializeField] private float moveSpeed = 0.7f;

    private void Awake() {
        rb = GetComponent<Rigidbody2D>();
    }
    private void FixedUpdate()   {
        moveH = Input.GetAxis("Horizontal") * moveSpeed;
        moveV = Input.GetAxis("Vertical") * moveSpeed;
      
        Vector2 direction = new Vector2(moveH, moveV);
        rb.velocity = direction.normalized;
        FindObjectOfType<PlayerAnimation>().SerDirection(direction);
    }
}
