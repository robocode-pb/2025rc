using UnityEngine;
using UnityEngine.UI;
public class PlayerSetting : MonoBehaviour{
    public GameObject MainLostPanel;
    int HP = 3;
    public Image HPImage;
    public Sprite[] HPsprite;
    
    public void damage(Vector3 EnemypPos){
        HP--;
        HPImage.sprite = HPsprite[HP];
        transform.Translate(
            translation: (EnemypPos-transform.position) * - 2f
        );
        if(HP<0){
            MainLostPanel.SetActive(true);
            Time.timeScale = 0f;
        }
    }

    void Start(){
        Time.timeScale = 1f;
    }

    void Update(){
        if(HP<0){
            MainLostPanel.SetActive(true);
            Time.timeScale = 0f;
        }
    }
}
