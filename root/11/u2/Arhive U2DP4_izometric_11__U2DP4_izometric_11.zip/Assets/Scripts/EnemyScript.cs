using UnityEngine;
using UnityEngine.UI;

public class EnemyScript : MonoBehaviour{
   public int HP;
    public Slider EnemyHealth;
    void Start(){ 
    //   FindObjectOfType<SoundManagerScript>().Play_oaA();  
       EnemyHealth.maxValue = HP;
       EnemyHealth.value    = HP;
    }   

    void Update(){
        
    }
    void OnTriggerEnter2D(Collider2D c){
        if(c.gameObject.CompareTag("Bullet")){
             FindObjectOfType<SoundManagerScript>().Play_paA();  
            Destroy(c.gameObject);
            HP--;
            if(HP<=0) Destroy(gameObject);
            EnemyHealth.value    = HP;

        }
    }
     void OnCollisionEnter2D(Collision2D c){
        if(c.gameObject.CompareTag("Player")){
            c.gameObject.GetComponent<PlayerSetting>().damage(transform.position);
        }
    } 
}