using UnityEngine;

public class MuzzelScript : MonoBehaviour{
    public GameObject bullet;
    void Update(){
        if(Input.GetMouseButtonDown(0)){
            transform.parent.GetComponent<Animator>().SetTrigger("shoot");
           GameObject b = Instantiate(bullet, transform.position, Quaternion.identity);
           b.GetComponent<Rigidbody2D>().AddForce(
            transform.parent.transform.right *5,
            ForceMode2D.Impulse
           );
            Destroy(b, 2);
        }
    }
}

