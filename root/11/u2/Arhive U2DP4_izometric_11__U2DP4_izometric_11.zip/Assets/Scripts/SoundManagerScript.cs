using UnityEngine;

public class SoundManagerScript : MonoBehaviour{
           AudioSource audioSource; 
    public AudioClip odA;     // o-ogr p-player d-death a-attack d-damage A-Audio
    public AudioClip oaA;
    public AudioClip pdA;
    public AudioClip paA;
    public AudioClip bgA;
    
    void Start(){
        audioSource = gameObject.GetComponent<AudioSource>();
    }

    public void Play_odA(){ audioSource.PlayOneShot(odA); }
    public void Play_oaA(){ audioSource.PlayOneShot(oaA); }
    public void Play_pdA(){ audioSource.PlayOneShot(pdA); }
    public void Play_paA(){ audioSource.PlayOneShot(paA); }

}
