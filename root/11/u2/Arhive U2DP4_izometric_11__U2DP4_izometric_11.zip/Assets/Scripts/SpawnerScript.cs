using UnityEngine;

public class SpawnerScript : MonoBehaviour
{
   public GameObject Jewel;
    public float height;
    public float width;
    void Start(){
        InvokeRepeating("JewelSpawner", 0, 10f);
    }

    void JewelSpawner(){
        Instantiate(Jewel, new Vector3(
            transform.position.x + Random.Range( -width,width),
            transform.position.y + Random.Range(-height,height),
            0
        ), Quaternion.identity);
    }

 void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1, 0, 0 , 0.4f);
        Gizmos.DrawCube(transform.position, new Vector3(width*2, height*2, 1));
    }

}
