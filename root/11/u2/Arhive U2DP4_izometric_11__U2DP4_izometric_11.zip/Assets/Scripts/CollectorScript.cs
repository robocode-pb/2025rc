using UnityEngine;
using UnityEngine.UI;

public class CollectorScript : MonoBehaviour{
    int Jewels = 0;
    public Text JewelIsText;

    void OnTriggerEnter2D(Collider2D c){
        if(c.gameObject.CompareTag("Jewel")){
            Destroy(c.gameObject);
            Jewels++;
            JewelIsText.text = ""+Jewels;
        }
    }
}
 