using UnityEngine;

public class Gun : MonoBehaviour{
    SpriteRenderer sprite;
    
    void Start(){
        sprite = gameObject.GetComponent<SpriteRenderer>();
    }

    void Update(){
        Vector3 worldPosition = Camera.main.ScreenToWorldPoint(
            new Vector2(Input.mousePosition.x, Input.mousePosition.y)
        );
        worldPosition.z = 0;

        transform.right = worldPosition - transform.position;

        // Debug.Log(transform.rotation.z);

        if (transform.rotation.z > -0.7f && transform.rotation.z < 0.7f){
            sprite.flipY = false;
        }else{
            sprite.flipY = true;
        }

    }
}
