using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ButtonController : MonoBehaviour
{
    public void ClickREstart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void ClickNext()
    {
        SceneManager.LoadScene(
            SceneManager.GetActiveScene().buildIndex + 1
        );
    }

    public void ClickMenu()
    {
        SceneManager.LoadScene(0);
    }
    
    public void ClickOpenLevel(int levelIndex){
        SceneManager.LoadScene(levelIndex);
    }

}

