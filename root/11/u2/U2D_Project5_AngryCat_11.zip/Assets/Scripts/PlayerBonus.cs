using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBonus : MonoBehaviour
{
    void Start(){
        
    }

    void Update(){
        
    }
    void OnTriggerEnter2D(Collider2D collision){
        if(collision.gameObject.CompareTag("GravityZone")){
            gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
        }
    }
     void OntriggerExit2D(Collider2D collision){
        if(collision.gameObject.CompareTag("GravityZone")){
            gameObject.GetComponent<Rigidbody2D>().gravityScale = 1;
        }

    }
}
