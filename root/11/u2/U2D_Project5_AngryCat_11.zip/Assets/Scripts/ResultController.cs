using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultController : MonoBehaviour{
    public int bestTime = 15;
    float timer = 0;
    public Text timerText;
    public Text starText;
    public  GameObject panelRespawn;
    public  GameObject panelWin;

    public void StartTimer(){ InvokeRepeating("Tick", 0, 0.1f); }
    public void StopTimer(){ CancelInvoke(); }
    void Tick(){
        timer += 0.1f;
        timerText.text =  " "+timer+"s";

    }
    public void ShowPanelRespawn(){
        panelRespawn.SetActive(true);
        if(timer <= bestTime){
            starText.text = "You got 3 stars!";
        }else if(timer <= bestTime*2){
            starText.text = "You got 2 stars!";
        }else {
            starText.text = "You got 1 star!";
            }
        }

        public void ShowPanelWin(){
        panelWin.SetActive(true);
        if(timer <= bestTime){
            starText.text = "You got 3 stars!";
        }else if(timer <= bestTime*2){
            starText.text = "You got 2 stars!";
        }else {
            starText.text = "You got 1 star!";
            }
        }
        
   void Start(){
        
    }

    void Update(){
        
    }
}
