using UnityEngine;

public class ObstacleScript : MonoBehaviour{
    public int damageValue = 1;
}
