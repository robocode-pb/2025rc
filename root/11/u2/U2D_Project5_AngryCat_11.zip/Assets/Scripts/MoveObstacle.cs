using UnityEngine;

public class MoveObstacle : MonoBehaviour{
    public Transform start, end;
    public float speed = 5.0f;
    bool up = false;
    void Update(){
        if       (transform.position.y >= end.position.y){
            up = false;
        }else if (transform.position.y <= start.position.y){
            up = true;
        }
        if (up == true){
            transform.Translate(  Vector3.up * speed * Time.deltaTime );
        }else{
            transform.Translate( -Vector3.up *speed/2* Time.deltaTime );
        }
    }
}
