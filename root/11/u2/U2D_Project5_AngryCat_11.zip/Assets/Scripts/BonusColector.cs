using UnityEngine;
using UnityEngine.UI;

public class BonusColector : MonoBehaviour
{
    public Text textCoin;
    public int b0speed = 0;   // збільшити швидкість
    public int b1time = 0;    // уповільнити час
    public int b2gravity = 0; // зменшення гравітації
    public int b3size = 0;    // зменшення розміру
    public int b4hammer = 0;  // руйнування стін
    public int b5light = 0;   // можна бачити в темряві

    int[] price = { 1, 2, 3, 4, 5, 6 }; // ціна кожного бонуса
    public Button[] buttons = new Button[6]; // зарезервувати для кнопок

    void Start(){
        b0speed   = PlayerPrefs.GetInt("b0speed",   0);
        b1time    = PlayerPrefs.GetInt("b1time",    0);
        b2gravity = PlayerPrefs.GetInt("b2gravity", 0);
        b3size    = PlayerPrefs.GetInt("b3size",    0);
        b4hammer  = PlayerPrefs.GetInt("b4hammer",  0);
        b5light   = PlayerPrefs.GetInt("b5light",   0);
        PlayerPrefs.SetInt("money", 100000);
        for (int i = 0; i < buttons.Length; i++){
            // кожна кнопка по черзі, беремо її дитину Текст і замінюємо текст на ціну
            buttons[i].transform.GetChild(0).GetComponent<Text>().text = ""+price[i];
            int index = i; // локальна копія змінної для замикання
            buttons[i].onClick.AddListener(() => ButtonClick(index));
        }
    }
     void Update(){
        textCoin.text = ""+PlayerPrefs.GetInt("money", 0);
    }

    void ButtonClick(int index){
        FindObjectOfType<BonusBackPack>().Start(); // викликати метод Start() з BonusBackPack
        int playerMoney = PlayerPrefs.GetInt("money", 0);
        if (playerMoney >= price[index]) {
            PlayerPrefs.SetInt("money", playerMoney - price[index]);
           // buttons[index].interactable = false;
           // buttons[index].transform.GetChild(0).GetComponent<Text>().text = "продано";
            switch(index){
                case 0:
                    b0speed +=1;
                    PlayerPrefs.SetInt("b0speed", b0speed);
                break;
                case 1:
                    b1time +=1;
                    PlayerPrefs.SetInt("b1time", b1time);
                break;
                case 2:
                    b2gravity +=1;
                    PlayerPrefs.SetInt("b2gravity", b2gravity);
                break;
                case 3:
                    b3size +=1;
                    PlayerPrefs.SetInt("b3size", b3size);
                break;
                case 4:
                    b4hammer +=1;
                    PlayerPrefs.SetInt("b4hammer", b4hammer);
                break;
                case 5:
                    b5light +=1;
                    PlayerPrefs.SetInt("b5light", b5light);
                break;
            }
        }
    }

}
