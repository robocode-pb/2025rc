using UnityEngine;
using UnityEngine.UI;

public class BonusBackPack : MonoBehaviour
{
    Text[] bonusTexts = new Text[6]; // Тексти для відображення значень бонусів
    public Button[] buttons = new Button[6]; // Кнопки для взаємодії з бонусами

    int[] bonusValues = new int[6]; // Масив для зберігання значень бонусів
    string[] bonusKeys = { "b0speed", "b1time", "b2gravity", "b3size", "b4hammer", "b5light" }; // Ключі PlayerPrefs

   public void Start()
    {
        PlayerPrefs.SetInt("coin", 100); // Ініціалізація PlayerPrefs для монет
        // Завантаження значень бонусів із PlayerPrefs
        for (int i = 0; i < bonusKeys.Length; i++)
        {
            bonusTexts[i]= buttons[i].GetComponentInChildren<Text>();

            bonusValues[i] = PlayerPrefs.GetInt(bonusKeys[i], 0);
            UpdateBonusText(i); // Оновлення тексту для кожного бонуса

            int index = i; // Локальна копія змінної для замикання
            buttons[i].onClick.RemoveAllListeners(); // Очистка попередніх слухачів
 
            buttons[i].onClick.AddListener(() => OnButtonClick(index));
        }
    }

    void OnButtonClick(int index)
    {
        if (bonusValues[index] <= 0) return; // Перевірка наявності бонуса
        // Логіка для взаємодії з бонусами (наприклад, збільшення значення)
        bonusValues[index]--;
        PlayerPrefs.SetInt(bonusKeys[index], bonusValues[index]);
        UpdateBonusText(index); // Оновлення тексту після зміни значення
    }

    void UpdateBonusText(int index)
    {
        // Оновлення тексту для відображення значення бонуса
        bonusTexts[index].text = $"{bonusValues[index]}";
    }
}