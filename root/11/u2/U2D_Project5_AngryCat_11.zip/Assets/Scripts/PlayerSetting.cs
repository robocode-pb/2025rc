using UnityEngine;
using UnityEngine.UI;

public class PlayerSetting : MonoBehaviour
{
    public int hp;
    public Slider hpSlider;
    void Start() { hpSlider.maxValue = hp;}
    void Update() { hpSlider.value = hp; }
    void OnTriggerEnter2D(Collider2D c){
        if (c.gameObject.CompareTag("Obstacle")){
            hp -= c.gameObject.GetComponent<ObstacleScript>().damageValue;
            if (hp <= 0){
                FindObjectOfType<ResultController>().StopTimer();
                FindObjectOfType<ResultController>().ShowPanelRespawn();
                Destroy(gameObject); // Destroy the player object
            }
        }
    }
}