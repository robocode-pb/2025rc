﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerTankSetting : MonoBehaviour
{
    [SerializeField] private float maxHealth;
    [SerializeField] private float currentHealth;

    [SerializeField] private Slider healthSlider;  // Прив’язати через інспектор

    private void Start()
    {
        currentHealth = maxHealth;

        if (healthSlider != null)
        {
            healthSlider.minValue = 0;
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }
    }

    public void TakeDamage(float value)
    {
        currentHealth -= value;
        if (currentHealth < 0) currentHealth = 0;
        UpdateHealthSlider();

        if (currentHealth <= 0)
        {
            Debug.Log("Tank Destroy");
            // Можна додати смерть або інші дії
        }
    }

    public void Repair(float value)
    {
        currentHealth += value;
        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }
        UpdateHealthSlider();
    }
    void OnTriggerEnter2D(Collider2D c)
    {
        if (c.gameObject.CompareTag("EnemyBullet"))
        {
            Destroy(c.gameObject);
            TakeDamage(10f);
            if (currentHealth <= 0)
            {
                SceneManager.LoadScene(0);
            }
        }
        
    }

    private void UpdateHealthSlider()
    {
        if (healthSlider != null)
        {
            healthSlider.value = currentHealth;
        }
    }
}
