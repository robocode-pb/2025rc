using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class LevelController_f : MonoBehaviour{
    [SerializeField] float Speed = 0.1f;
    [SerializeField] float EndPositionX = -5f;
    
    void Start(){
        
    }

    void Update(){
        transform.Translate(Vector2.left * Speed * Time.deltaTime);
        if(transform.position.x < EndPositionX){
            transform.position = Vector3.zero;
        }
    }
}
