using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class CatController_f : MonoBehaviour{
    bool canJump = false;
    Rigidbody2D rb2d;
    int Score = 0;
    [SerializeField] GameObject ScoreText;
    [SerializeField] float JumpForse = 2;
    // Start is called before the first frame update
    void Start(){
        rb2d = gameObject.GetComponent<Rigidbody2D>();
    }
    void Update(){
        if((Input.GetKeyDown(KeyCode.Space) && canJump) 
        
        ){
            canJump = false;
            rb2d.AddForce(Vector2.up*5f, ForceMode2D.Impulse);
            
        }
    }
    void OnCollisionEnter2D(Collision2D collision){
        if (collision.gameObject.tag == "Spike"){
            // Destroy(gameObject);
            Application.LoadLevel(Application.loadedLevel);
        }
        if (collision.gameObject.tag == "Ground"){
            canJump = true;
        }
    }

    void OnTriggerEnter2D(Collider2D collider){
        if(collider.gameObject.tag == "Coin"){
            Destroy(collider.gameObject);
            Score += 1;
            ScoreText.GetComponent<Text>().text = " "+Score;
        }
    }
}