using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController_f : MonoBehaviour
{
    [SerializeField] float Speed =  0.1f;
    void Start(){
        Destroy(gameObject, 10);
    }

    void Update(){
        transform.Translate(Vector2.left* Speed * Time.deltaTime);
    }
}
