using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class ObjectSpawner_f : MonoBehaviour{
    [SerializeField] GameObject SpawnPrefab;
    void Start(){ 
        InvokeRepeating("Spawn", 2, 2);
    }   // кожну 2 секунду викликати функцію Spawn

    void Spawn(){ 
        Instantiate(SpawnPrefab, transform.position, Quaternion.identity);
        // cстворити інстанс (клон) префаба
    }

    void Update(){

    }
}
