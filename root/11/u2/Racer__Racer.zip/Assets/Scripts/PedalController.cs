using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
 //engine-двигун
public class PedalController : MonoBehaviour,
                               IPointerDownHandler,
                               IPointerUpHandler    {
 
    public Sprite pedalDown, pedalUp;
 
    public bool pedalForward;
    public GameObject car;
    public void OnPointerDown(PointerEventData eventData){//коли натиснемо
        GetComponent<Image>().sprite = pedalDown;
        if (pedalForward){
            car.GetComponent<CarController>().moveForward = true;
        } else {
            car.GetComponent<CarController>().moveBackward = true;
        }       
    }
 
    public void OnPointerUp(PointerEventData eventData){//коли не натиснето
        GetComponent<Image>().sprite = pedalUp;
        if (pedalForward){
            car.GetComponent<CarController>().moveForward = false;
        } else {
            car.GetComponent<CarController>().moveBackward = false;
            //forward-вперед backward-назад if-якщо else-інакше
        }       
    }
}