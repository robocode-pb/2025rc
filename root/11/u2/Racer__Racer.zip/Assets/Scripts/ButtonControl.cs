using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour
{
    public void NextScene(){
        SceneManager.LoadScene(
                SceneManager.GetActiveScene().buildIndex+1
            );
    }
     public void firstScene(){
        SceneManager.LoadScene(0);
    }

    public void Quit(){
        Application.Quit();
    }

}
