﻿// Імпортуємо бібліотеку UnityEngine, яка надає основні функції для створення гри
using UnityEngine;
// Імпортуємо бібліотеку SceneManagement, яка дозволяє працювати зі сценами гри
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Оголошення публічного класу CarController, який наслідує функціонал від MonoBehaviour
public class CarController : MonoBehaviour
{
    // Оголошуємо публічне поле типу WheelJoint2D для заднього колеса
    public WheelJoint2D backWheel;
    // Оголошуємо публічне поле типу WheelJoint2D для переднього колеса
    public WheelJoint2D frontWheel;

    // Оголошуємо приватне поле типу JointMotor2D для управління мотором
    private JointMotor2D motor;

    // Публічне булеве поле для визначення руху вперед
    public bool moveForward = false;
    // Публічне булеве поле для визначення руху назад
    public bool moveBackward = false;
    // Приватне поле для зберігання швидкості, ініціалізоване значенням 0
    private float speed = 0f;
    public bool isGround;
    Rigidbody2D rb2d;
    public Text FuelText;
    // Метод Start() викликається один раз при завантаженні скрипта
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        // Ініціалізуємо максимальний крутний момент мотора
        motor.maxMotorTorque = 1000;
    }

    // Метод Update() викликається кожен кадр
    void Update()
    {
        isGround = (
            backWheel.GetComponent<Collider2D>().IsTouchingLayers()
        || frontWheel.GetComponent<Collider2D>().IsTouchingLayers()
        );

        // Скидаємо значення змінних руху до false перед обробкою вводу
        moveForward = false;
        moveBackward = false;

        // Перевіряємо, чи натиснута клавіша "стрілка вгору"
        if (Input.GetKey(KeyCode.RightArrow))
        {
            // Якщо натиснута, встановлюємо значення moveForward в true
            moveForward = true;
        }
        // Перевіряємо, чи натиснута клавіша "стрілка вниз"
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            // Якщо натиснута, встановлюємо значення moveBackward в true
            moveBackward = true;
        }

        // Перевіряємо, чи натиснута клавіша "R" для перезавантаження сцени
        if (Input.GetKey(KeyCode.R))
        {
            // Викликаємо метод Respawn для перезавантаження сцени
            Respawn();
        }
    }

    // Метод FixedUpdate() викликається з фіксованою частотою для фізичних обчислень
    void FixedUpdate()
    {
        // Викликаємо метод MoveOnGround для обробки руху
        if(isGround) MoveOnGround();
        else         MoveOnAir();
        CheckGameOver();
    }
    void MoveOnAir()
    {
        if       (moveForward && rb2d.angularVelocity < 200)
        {
            rb2d.AddTorque(10f);
        }
         else if (moveBackward && rb2d.angularVelocity >-200)
        {
            rb2d.AddTorque(-10f); // ok._.
        }
    }
    // Метод MoveOnGround() обробляє рух автомобіля
    void MoveOnGround()
    {
        // Перевіряємо, чи рухаємось вперед і чи швидкість колеса не перевищує -2000
        if (moveForward && frontWheel.attachedRigidbody.angularVelocity > -2000)
        {
            // Збільшуємо швидкість на 40
            speed += 40;
        }
        // Перевіряємо, чи рухаємось назад і чи швидкість колеса не перевищує 2000
        else if (moveBackward && frontWheel.attachedRigidbody.angularVelocity < 2000)
        {
            // Зменшуємо швидкість на 40
            speed -= 40;
        }

        // Якщо автомобіль рухається вперед або назад
        if (moveForward || moveBackward)
        {
            // Встановлюємо швидкість мотора
            motor.motorSpeed = speed;
            // Призначаємо мотор передньому колесу
            frontWheel.motor = motor;
            // Призначаємо мотор задньому колесу
            backWheel.motor = motor;
            // Активуємо використання мотора для обох коліс
            backWheel.useMotor = true;
            frontWheel.useMotor = true;
        }
        else // Якщо автомобіль не рухається
        {
            // Оновлюємо швидкість у протилежному напрямку до кутової швидкості переднього колеса
            speed = -frontWheel.attachedRigidbody.angularVelocity;
            // Вимикаємо використання мотора для обох коліс
            backWheel.useMotor = false;
            frontWheel.useMotor = false;
        }
    }

    // Метод Respawn() перезавантажує поточну сцену
    void Respawn()
    {
        // Завантажуємо активну сцену за її індексом
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    // Метод OnTriggerEnter2D() викликається при входженні колайдера в тригер
    void OnTriggerEnter2D(Collider2D collider)
    {
        // Перевіряємо, чи об'єкт має тег "DeathZone"
        if (collider.gameObject.CompareTag("DeathZone"))
        {
            // Викликаємо метод Respawn для перезавантаження сцени
            Respawn();
        }
    }
    void CheckGameOver(){
        Vector2 rayDir = Vector2.up;
        RaycastHit2D[] hit = Physics2D.RaycastAll(
            transform.position, 
            rayDir, 
            5f
        );
        Debug.DrawRay(
            transform.position, 
            rayDir * 2f,
            Color.red
        );
        if(hit.Length > 1){ Respawn(); }
    }
}