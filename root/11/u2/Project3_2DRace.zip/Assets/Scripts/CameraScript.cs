﻿// Імпортуємо бібліотеку UnityEngine для доступу до основних компонентів Unity
using UnityEngine;

// Оголошуємо публічний клас CameraScript, який наслідує MonoBehaviour
public class CameraScript : MonoBehaviour
{
    // Поле з атрибутом [SerializeField] дозволяє редагувати його значення у редакторі Unity
    [SerializeField] GameObject target; // Об'єкт, за яким буде слідкувати камера

    // Метод Start() викликається один раз при завантаженні скрипта
    void Start()
    {
        // Цей метод наразі порожній, але може використовуватись для ініціалізації
    }

    // Метод Update() викликається кожен кадр і використовується для оновлення положення камери
    void Update()
    {
        // Створюємо вектор для збереження позиції цільового об'єкта
        Vector3 targetpos = target.transform.position;
        
        // Зберігаємо значення Z-позиції камери, щоб вона не змінювала свою глибину
        targetpos.z = transform.position.z;
        
        // Переміщуємо камеру до цільової позиції з використанням лінійної інтерполяції для плавного руху
        transform.position = Vector3.Lerp(transform.position, targetpos, Time.deltaTime * 1000);
    }
}
