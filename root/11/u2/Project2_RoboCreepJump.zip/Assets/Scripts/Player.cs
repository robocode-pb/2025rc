using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    public float movementSpeed = 10f;
    private float _directionMove;
    private Rigidbody2D _playerRb;
    
    public GameObject jewel;
    private int score = 0;
    public GameObject scoretext;
    private Animator _playerAnimator;
    private int _state = 0;
    private void Start() {
        _playerRb = GetComponent<Rigidbody2D>(); 
        _playerAnimator = GetComponent<Animator>(); 
    }
    
    private void Update(){
        _directionMove = Input.GetAxis("Horizontal")*movementSpeed;
        _playerAnimator.SetInteger("state", _state);
        if(_playerRb.velocity.y > 0){
            _state = 1;
        }else if(_playerRb.velocity.y < 0){
            _state = -1;
        } else {
            _state = 0;
        }
    }

    private void FixedUpdate(){
        Vector2 velocity = _playerRb.velocity;
        velocity.x = _directionMove;
        _playerRb.velocity = velocity;
    }
    void OnTriggerEnter2D(Collider2D collider){
        if(collider.gameObject.CompareTag("Jewel")){
        Destroy(collider.gameObject);
        score += 1;
        scoretext.GetComponent<Text>().text = "1"+score;
        }


}
}
