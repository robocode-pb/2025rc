using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGenerator : MonoBehaviour
{
    public float minX = -2.0f;
    public float maxX =  2.0f;
    public float Y    = -1.0f;
    public float Ystep = 3f;
    public int objectCount = 10;
    public GameObject platform;

    public GameObject jewel;

    void Start(){
        SpawnPlatform();
    }
    void Update(){
    
    }
    public void SpawnPlatform(){
        for(int i = 0; i < objectCount; i++){
            // Debug.Log(Random.Range(minX, maxX));
            Instantiate(platform, 
                        new Vector3(Random.Range(minX, maxX), Y, 0), 
                        Quaternion.identity);
            Instantiate(jewel, 
                        new Vector3(Random.Range(minX, maxX), Y+1, 0), 
                        Quaternion.identity);
            Y = Y + Random.Range(Ystep/2, Ystep);
        }
    }
}
