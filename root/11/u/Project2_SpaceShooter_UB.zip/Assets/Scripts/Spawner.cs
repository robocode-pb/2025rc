using UnityEngine;

public class Spawner : MonoBehaviour
{
    // Публічне поле для об'єкта, який потрібно спавнити
    public GameObject objectToSpawn;

    // Публічне поле для шансу спавну (у відсотках)
    [Range(0, 100)]
    public float spawnChance = 50f;

    // Публічне поле для кількості спавнів на секунду
    public float spawnsPerSecond = 1f;

    private float spawnAreaWidth;
    private float spawnAreaHeight;
    private float timeBetweenSpawns;

    void Start()
    {
        // Визначення інтервалу між спавнами
        timeBetweenSpawns = 1f / spawnsPerSecond;

        // Визначення розмірів зони спавну
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();
        if (spriteRenderer != null)
        {
            spawnAreaWidth = spriteRenderer.bounds.size.x;
            spawnAreaHeight = spriteRenderer.bounds.size.y;
        }
        else
        {
            Debug.LogWarning("Об'єкт не має SpriteRenderer. Зона спавну за замовчуванням встановлена у (1, 1).");
            spawnAreaWidth = 1f;
            spawnAreaHeight = 1f;
        }

        // Запуск циклу спавну
        InvokeRepeating(nameof(AttemptSpawn), 0f, timeBetweenSpawns);
    }

    void AttemptSpawn()
    {
        // Перевірка шансу спавну
        if (Random.Range(0f, 100f) <= spawnChance)
        {
            SpawnObject();
        }
    }

    void SpawnObject()
    {
        // Визначення випадкової позиції всередині зони спавну
        Vector2 spawnPosition = new Vector2(
            Random.Range(-spawnAreaWidth / 2f, spawnAreaWidth / 2f),
            Random.Range(-spawnAreaHeight / 2f, spawnAreaHeight / 2f)
        );

        // Спавн об'єкта
        Instantiate(objectToSpawn, (Vector2)transform.position + spawnPosition, Quaternion.identity);
    }
}
