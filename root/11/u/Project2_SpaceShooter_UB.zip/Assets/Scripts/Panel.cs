using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Panel : MonoBehaviour
{
      public GameObject panel; // Панель, яку потрібно вимкнути

    // Метод для кнопки Start
    public void OnStartButton()
    {
        Time.timeScale = 1f; // Відновлює швидкість часу
        if (panel != null)
        {
            panel.SetActive(false); // Вимикає панель
        }
    }

    // Метод для кнопки Quit
    public void OnQuitButton()
    {
        Debug.Log("Quit Game"); // Для перевірки в редакторі
        Application.Quit(); // Закриває гру
    }
}
